use ig_clone;
SELECT 
    *
FROM
    `users`;

/*
 1. Rewarding Most Loyal Users :
--Find the 5 oldest users of the Instagram from the database provided
*/

SELECT 
    *
FROM
    users
ORDER BY created_at ASC
LIMIT 5;

/*
 2. Remind Inactive Users to Start Posting: 
 -- Find the users who have never posted a single photo on Instagram
*/
SELECT 
    *
FROM
    photos;

SELECT 
     users.id, username, image_url, created_at
FROM
    users
        LEFT JOIN
    photos ON users.id = photos.user_id
WHERE
    photos.id IS NULL;
    

/*
 3. Declaring Contest Winner: 
 --  Identify the winner of the contest and provide their details to the team
*/

SELECT 
    photos.id,
    username,
    photos.image_url,
    COUNT(*) AS Total_Likes
FROM
    photos
        INNER JOIN
    likes ON likes.photo_id = photos.id
        INNER JOIN
    users ON photos.user_id = users.id
GROUP BY photos.id
ORDER BY Total_Likes DESC
LIMIT 1;

/*
 4. Hashtag Researching: 
 --  Identify and suggest the top 5 most commonly used hashtags on the platform
*/

SELECT 
    tags.tag_name, COUNT(*) AS total_times_tagsUsed
FROM
    photo_tags
        INNER JOIN
    tags ON photo_tags.tag_id = tags.id
GROUP BY tags.id
ORDER BY total_times_tagsUsed DESC
LIMIT 5;

/*
 5. Launch AD Campaign: 
 -- What day of the week do most users register on? Provide 
    insights on when to schedule an ad campaign
*/

SELECT 
    DAYNAME(created_at) AS Day, COUNT(*) AS Total_RegisteredMostly
FROM
    users
GROUP BY Day
ORDER BY Total_RegisteredMostly DESC
LIMIT 2;

