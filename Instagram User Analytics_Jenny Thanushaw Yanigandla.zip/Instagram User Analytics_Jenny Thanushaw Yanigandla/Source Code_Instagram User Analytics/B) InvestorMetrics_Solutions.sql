use ig_clone;


/* 1. User Engagement:
 -- Provide how many times does average user posts 
 on Instagram. Also, provide the total number of photos 
 on Instagram/total number of users 
 */
 
SELECT 
    USER_ID, COUNT(id) AS photos_posted
FROM
    photos
GROUP BY user_id;


SELECT 
    COUNT(id) AS TotalUsers
FROM
    users;


SELECT 
    COUNT(id) AS TotalPhotos
FROM
    photos;

SELECT 
    (SELECT 
            COUNT(*)
        FROM
            photos) / (SELECT 
            COUNT(*)
        FROM
            users) AS avg_postsPerUser;
 
 
 /*
 2. Bots & Fake Accounts: 
 -- Provide data on users (bots) who have liked every single photo 
 on the site (since any normal user would not be able to do this).
 */
 
 SELECT 
    username, COUNT(*) AS total_likes
FROM
    users
        INNER JOIN
    likes ON users.id = likes.user_id
GROUP BY likes.user_id
HAVING total_likes = (SELECT 
        COUNT(*) AS total_photos
    FROM
        photos);
 
 
SELECT 
    PHOTO_ID, COUNT(user_id) AS Total_Likes_Count
FROM
    LIKES
GROUP BY photo_id
ORDER BY photo_id;
-- There is no likes more than 100 hence there is no bot user.

select*
from tags;

 